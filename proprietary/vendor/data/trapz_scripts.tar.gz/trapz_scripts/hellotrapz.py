#!/usr/bin/python

VERSION = '0.1'

"""
Script examples using SimpleTrapz for analyzing TRAPZ output.
"""

if __name__ == "__main__":


    from trapztool import SimpleTrapz
    import argparse

    description = "Examples of simple trapz analysis scripts"
    parser = argparse.ArgumentParser(description=description,
    formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('xmlfile', help='filename of XML-format TRAPZ log dump')
    args = parser.parse_args()

    trapzfile = args.xmlfile

    ### parse an XML dump file into a symbol DOM and list of events ###

    strapz = SimpleTrapz(trapzfile)





    ### degenerate test, get all trace event elements ###

    entire_list = strapz.filterEvents()
    print "all trace events count: ", len(entire_list)





    ### filtering events by component, then refining a filter on a subset of those results ###

    game_draw_events = strapz.filterEvents("FluidityLab.GameDrawThread")
    print "game_draw_events count: ", len(game_draw_events)

    # refined search on slice of first 10 results
    frame_events = strapz.filterEvents("FluidityLab.GameDrawThread","frame",game_draw_events[:10])
    print "frame_events in slice count: ", len(frame_events)





    ### elemenatary analysis - calculate max frame interval ###

    # all frame events
    frame_events = strapz.filterEvents("FluidityLab.GameDrawThread","frame")

    # need running max value, but can't assign to a normal variable
    # in this scope from within the function (until 'nonlocal' in python 3.+)
    max_interval = [0]

    def check_interval(first,second):
    interval = second.timestamp-first.timestamp
    interval *= 1000
    max_interval[0] = max(max_interval[0],interval)

    # pass consecuitive pairs of events to 'check_interval'
    map(check_interval,frame_events[:-1], frame_events[1:])

    print "max frame interval: ", max_interval[0]





    ### sequence operations example ###

    # for every 'draw' trace that has extra_0 == 1, make
    # sure the next draw trace has extra_0 == 0

    all_draw = strapz.filterEvents("FluidityLab.GameDrawThread", "draw")
    draw_ex_1 = filter( lambda x: x.e1 == 1, all_draw)

    valid_following_draw = True

    for ev in draw_ex_1:
    next_draw = strapz.findNextEvent(ev, "FluidityLab.GameDrawThread", "draw", all_draw)

    if next_draw.e1 != 0:
        print "BOGUS:\n%20s"%"after draw event: ", vars(ev), "\n%20s"%"we found: ", vars(next_draw), "\n%20s"%"ex1 == 0?: "
        valid_following_draw = False

    print "all draw events following e1 == 1 had e1 == 0? ", valid_following_draw

